export const data = [
  { id: 1, jobRole: "UI / UX Developer", location: "Bngalore" },
  { id: 2, jobRole: "Java Developer", location: "Bngalore" },
  { id: 3, jobRole: "React Developer", location: "Bngalore" },
  { id: 4, jobRole: "React Native Developer", location: "Bngalore" },
  { id: 5, jobRole: "UI / UX Developer", location: "Hyderabad" },
  { id: 6, jobRole: "UI / UX Developer", location: "Chennai" },
  { id: 7, jobRole: "Java Developer", location: "Chennai" },
];
