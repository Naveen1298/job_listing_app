const LOGIN_API =
  "https://dev123.gigin.ai/abc/index.php/Api_controller/login_email";

export { LOGIN_API };
